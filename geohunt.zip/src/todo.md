1)
    Delete lobbys when empty
    Allocate new host tag after current host leaves.

2)
    not removing player from lobby after player leaves.